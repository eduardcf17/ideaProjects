public interface Relacions {
    // Retorna true si a es major que b
    boolean esMajor (Object b);
    // Retorna true si a es menor que b
    boolean esMenor (Object b);
    // Retorna true si a es igual que b
    boolean esIgual (Object b);


}
