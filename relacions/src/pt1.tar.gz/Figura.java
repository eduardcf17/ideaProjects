public interface Figura{
    float PI = 3.1416f;
    float area();
}