public class Mult10Exception extends RuntimeException {
    public Mult10Exception(String s) {
        super(s);
    }
}
