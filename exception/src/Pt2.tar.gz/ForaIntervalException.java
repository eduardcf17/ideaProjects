public class ForaIntervalException extends RuntimeException {
    public ForaIntervalException(String s) {
        super(s);
    }
}
